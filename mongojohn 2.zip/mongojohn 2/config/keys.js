module.exports = {
    MongoURI: 
    'mongodb+srv://sitihajar:Babanyonya96@freecluster.j8uru.mongodb.net/JohnLifeWheel?retryWrites=true&w=majority'
}